/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/types/index.ts":
/*!****************************!*\
  !*** ./src/types/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_SETTINGS: () => (/* binding */ DEFAULT_SETTINGS)
/* harmony export */ });
const DEFAULT_SETTINGS = {
    openaiUrl: 'https://openrouter.ai/api/v1',
    model: 'google/gemini-2.0-flash-001',
    enableAutoReply: false,
    enableAutoSubmit: false,
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/popup/options.ts ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../types */ "./src/types/index.ts");

class SettingsManager {
    constructor() {
        this.form = document.getElementById('settingsForm');
        this.urlInput = document.getElementById('openaiUrl');
        this.apiKeyInput = document.getElementById('apiKey');
        this.modelSelect = document.getElementById('model');
        this.customModelSection = document.getElementById('customModelSection');
        this.customModelInput = document.getElementById('customModel');
        this.backButton = document.getElementById('backButton');
        this.toast = document.getElementById('toast');
        this.initializeForm();
        this.initializeEventListeners();
    }
    showToast(message, type) {
        this.toast.textContent = message;
        this.toast.className = `${type} show`;
        setTimeout(() => {
            this.toast.className = type;
        }, 3000);
    }
    initializeEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        this.backButton.addEventListener('click', () => {
            window.location.href = 'index.html';
        });
        // Toggle custom model input visibility
        this.modelSelect.addEventListener('change', () => {
            const isCustom = this.modelSelect.value === 'custom';
            this.customModelSection.classList.toggle('hidden', !isCustom);
            if (isCustom) {
                this.customModelInput.focus();
            }
        });
        // Save settings form submit handler
        const saveButton = document.getElementById('saveSettings');
        if (saveButton) {
            saveButton.addEventListener('click', async (e) => {
                e.preventDefault();
                try {
                    await this.saveSettings();
                    this.showToast('Settings saved successfully!', 'success');
                }
                catch (error) {
                    this.showToast('Failed to save settings', 'error');
                    console.error('Error saving settings:', error);
                }
            });
        }
    }
    async initializeForm() {
        // Load saved settings
        const settings = await this.getSettings();
        this.loadSettings(settings);
        // Populate other form fields
        this.urlInput.value = settings.openaiUrl;
    }
    async loadSettings(settings) {
        if (settings.model === 'custom') {
            this.customModelSection.classList.remove('hidden');
            this.customModelInput.value = settings.model;
        }
        else {
            this.modelSelect.value = settings.model;
            this.customModelSection.classList.add('hidden');
        }
        this.apiKeyInput.value = settings.apiKey || '';
    }
    async getSettings() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['settings'], (result) => {
                resolve(result.settings || _types__WEBPACK_IMPORTED_MODULE_0__.DEFAULT_SETTINGS);
            });
        });
    }
    async saveSettings() {
        const settings = {
            openaiUrl: this.urlInput.value,
            apiKey: this.apiKeyInput.value || undefined,
            model: this.modelSelect.value === 'custom' ? this.customModelInput.value : this.modelSelect.value,
            enableAutoReply: false,
            enableAutoSubmit: false,
        };
        return new Promise((resolve, reject) => {
            chrome.storage.sync.set({ settings }, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                }
                else {
                    resolve();
                }
            });
        });
    }
    async handleSubmit(e) {
        e.preventDefault();
        try {
            await this.saveSettings();
            this.showToast('Settings saved successfully!', 'success');
        }
        catch (error) {
            this.showToast('Failed to save settings', 'error');
            console.error('Error saving settings:', error);
        }
        // Show success message
        const button = this.form.querySelector('button[type="submit"]');
        const originalText = button.textContent;
        button.textContent = 'Saved!';
        button.disabled = true;
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
        }, 2000);
    }
}
// Initialize settings manager when the options page loads
document.addEventListener('DOMContentLoaded', () => {
    new SettingsManager();
});

})();

/******/ })()
;
//# sourceMappingURL=options.js.map