/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/services/ai.ts":
/*!****************************!*\
  !*** ./src/services/ai.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   callAiModel: () => (/* binding */ callAiModel),
/* harmony export */   summarizeProfile: () => (/* binding */ summarizeProfile)
/* harmony export */ });
class LightOpenAI {
    constructor(config) {
        this.baseURL = config.baseURL;
        this.apiKey = config.apiKey;
    }
    async createChatCompletion(params) {
        const headers = {
            'Content-Type': 'application/json',
        };
        if (this.apiKey) {
            headers['Authorization'] = `Bearer ${this.apiKey}`;
        }
        const response = await fetch(`${this.baseURL}/chat/completions`, {
            method: 'POST',
            headers,
            body: JSON.stringify(params),
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`API error (${response.status}): ${error}`);
        }
        return response.json();
    }
}
async function callAiModel(prompt, settings) {
    try {
        const openai = new LightOpenAI({
            baseURL: settings.openaiUrl,
            apiKey: settings.apiKey,
        });
        const response = await openai.createChatCompletion({
            model: settings.model,
            messages: [{
                    role: 'user',
                    content: prompt
                }],
            temperature: 0.7,
        });
        return response.choices[0].message.content || '';
    }
    catch (error) {
        console.error('Error calling AI model:', error);
        throw new Error(`Failed to call AI model: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}
async function summarizeProfile(posts, existingContent = '', settings) {
    try {
        const prompt = `You are a Twitter profile analyzer. Given a set of tweets, create a concise profile description that captures the key characteristics, interests, and patterns in the user's tweets. If there's existing profile content, incorporate it and update with new insights.

${existingContent ? `Existing Profile Description:\n${existingContent}\n\n` : ''}

Tweets to analyze:
${posts.join('\n')}

Create a natural-sounding profile description that highlights:
1. Main topics and interests
2. Writing style and tone
3. Professional or personal focus
4. Notable patterns or themes`;
        return await callAiModel(prompt, settings);
    }
    catch (error) {
        console.error('Error summarizing profile:', error);
        throw new Error(`Failed to summarize profile: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}


/***/ }),

/***/ "./src/twitter/common.ts":
/*!*******************************!*\
  !*** ./src/twitter/common.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   convertTwitterPostToMarkdown: () => (/* binding */ convertTwitterPostToMarkdown),
/* harmony export */   extractAuthorInfo: () => (/* binding */ extractAuthorInfo)
/* harmony export */ });
function extractAuthorInfo(element) {
    const authorElement = element.querySelector('[data-testid="User-Name"]');
    const displayName = authorElement?.querySelector('span')?.textContent || '';
    const usernameElement = authorElement?.querySelector('[dir="ltr"]');
    const username = usernameElement?.textContent?.replace('@', '') || '';
    const profileUrl = `https://twitter.com/${username}`;
    return {
        username,
        displayName,
        profileUrl
    };
}
function convertTwitterPostToMarkdown(post) {
    console.log('Converting post(s) to markdown format');
    if (Array.isArray(post)) {
        return post.map(p => convertTwitterPostToMarkdown(p)).join('\n\n---\n\n');
    }
    let markdown = `## Tweet by [${post.author.displayName}](${post.author.profileUrl}) ${post.url ? `[🔗](${post.url})` : ''}\n`;
    markdown += `${post.content}\n\n`;
    // Add metadata if available
    const stats = [];
    if (post.likesCount)
        stats.push(`❤️ ${post.likesCount}`);
    if (post.retweetsCount)
        stats.push(`🔄 ${post.retweetsCount}`);
    if (post.repliesCount)
        stats.push(`💬 ${post.repliesCount}`);
    if (stats.length > 0) {
        markdown += `*${stats.join(' · ')}*\n`;
    }
    if (post.timestamp) {
        const date = new Date(post.timestamp);
        markdown += `*Posted on ${date.toLocaleDateString()}*\n`;
    }
    // Add replies if available
    if (post.replies && post.replies.length > 0) {
        markdown += '\n### Replies\n';
        post.replies.forEach(reply => {
            markdown += `\n**[${reply.author.displayName}](${reply.author.profileUrl})**\n`;
            markdown += `${reply.content}\n`;
            if (reply.timestamp) {
                const replyDate = new Date(reply.timestamp);
                markdown += `*Posted on ${replyDate.toLocaleDateString()}*\n`;
            }
            markdown += '---\n';
        });
    }
    // Add replyTo or originalPost if available
    if (post.type === 'reply') {
        markdown += '\n### Original Tweet\n';
        markdown += `**[${post.replyTo.author.displayName}](${post.replyTo.author.profileUrl})**\n`;
        markdown += `${post.replyTo.content}\n`;
        if (post.replyTo.timestamp) {
            const replyToDate = new Date(post.replyTo.timestamp);
            markdown += `*Posted on ${replyToDate.toLocaleDateString()}*\n`;
        }
    }
    else if (post.type === 'repost') {
        markdown += '\n### Original Tweet\n';
        markdown += `**[${post.originalPost.author.displayName}](${post.originalPost.author.profileUrl})**\n`;
        markdown += `${post.originalPost.content}\n`;
        if (post.originalPost.timestamp) {
            const originalPostDate = new Date(post.originalPost.timestamp);
            markdown += `*Posted on ${originalPostDate.toLocaleDateString()}*\n`;
        }
        if (post.hasQuote) {
            markdown += '\n### Quote Comment\n';
            markdown += `${post.quoteComment}\n`;
        }
    }
    console.log('Markdown conversion complete');
    return markdown;
}


/***/ }),

/***/ "./src/twitter/timeline.ts":
/*!*********************************!*\
  !*** ./src/twitter/timeline.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTwitterPosts: () => (/* binding */ extractTwitterPosts),
/* harmony export */   extractTwitterPostsFromAi: () => (/* binding */ extractTwitterPostsFromAi),
/* harmony export */   extractTwitterPostsFromDom: () => (/* binding */ extractTwitterPostsFromDom),
/* harmony export */   isTwitterProfileUrl: () => (/* binding */ isTwitterProfileUrl),
/* harmony export */   isTwitterReplyUrl: () => (/* binding */ isTwitterReplyUrl)
/* harmony export */ });
/* harmony import */ var _services_ai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/ai */ "./src/services/ai.ts");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common */ "./src/twitter/common.ts");


function isTwitterProfileUrl(url) {
    // Match twitter.com/username or x.com/username but not subpages
    // Also allow www subdomain
    return /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/?$/.test(url);
}
function isTwitterReplyUrl(url) {
    if (!url)
        return false;
    console.log("Checking if URL is a Twitter reply URL:", url);
    // Match Twitter's reply URL patterns more comprehensively
    return (
    // Match the /intent/tweet pattern
    /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/[^/]+\/tweet/.test(url) ||
        // Match the specific in_reply_to parameter
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/intent\/tweet\?in_reply_to=/.test(url) ||
        // Match the specific in_reply_to parameter for x.com
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/intent\/post\?in_reply_to=/.test(url) ||
        // Match URLs with status and reply in them
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/status\/[^/]+\/reply/.test(url));
}
function extractTwitterPostsFromDom() {
    try {
        console.log("Starting DOM extraction...");
        const posts = [];
        // Find all tweet articles
        const tweets = document.querySelectorAll('article[data-testid="tweet"]');
        console.log(`Found ${tweets.length} tweets`);
        tweets.forEach((tweet, index) => {
            console.log(`Processing tweet ${index + 1}...`);
            // Find the tweet text content
            const contentElement = tweet.querySelector('[data-testid="tweetText"]');
            if (!contentElement) {
                console.log("No content element found, skipping tweet");
                return;
            }
            const content = contentElement.textContent || "";
            console.log(`- Content: "${content.slice(0, 50)}..."`);
            // Extract author info
            const author = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(tweet);
            console.log(`- Author: ${author.displayName} (@${author.username})`);
            // Find the tweet time element
            const timeElement = tweet.querySelector("time");
            const timestamp = timeElement?.getAttribute("datetime") || "";
            console.log(`- Timestamp: ${timestamp || "not found"}`);
            // Find tweet stats
            const statsContainer = tweet.querySelector('[role="group"]');
            const stats = statsContainer?.querySelectorAll('[data-testid$="count"]') || [];
            const [repliesCount, retweetsCount, likesCount] = Array.from(stats).map((stat) => parseInt(stat?.textContent || "0", 10));
            console.log(`- Stats: ${repliesCount} replies, ${retweetsCount} retweets, ${likesCount} likes`);
            // Find tweet URL
            const linkElement = tweet.querySelector('a[href*="/status/"]');
            const url = linkElement?.getAttribute("href");
            const id = url?.split("/status/")?.[1] || "";
            console.log(`- Tweet ID: ${id || "not found"}`);
            // Check if it's a reply
            const replyElement = tweet.querySelector('[data-testid="tweet-reply-context"]');
            if (replyElement) {
                const replyToAuthor = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(replyElement);
                const replyToContent = replyElement.querySelector('[data-testid="tweetText"]')
                    ?.textContent || "";
                posts.push({
                    type: "reply",
                    id,
                    content: contentElement.textContent || "",
                    timestamp,
                    author,
                    likesCount,
                    retweetsCount,
                    repliesCount,
                    url: url ? `https://twitter.com${url}` : undefined,
                    replyTo: {
                        id: "",
                        content: replyToContent,
                        timestamp: "",
                        author: replyToAuthor,
                    },
                });
                return;
            }
            // Check if it's a repost
            const repostElement = tweet.querySelector('[data-testid="tweet-repost-context"]');
            if (repostElement) {
                const originalAuthor = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(repostElement);
                const quoteContent = tweet.querySelector('[data-testid="tweet-quoted"]')?.textContent ||
                    "";
                const hasQuote = Boolean(quoteContent);
                const quoteComment = hasQuote
                    ? contentElement.textContent || ""
                    : undefined;
                posts.push({
                    type: "repost",
                    id,
                    content: contentElement.textContent || "",
                    timestamp,
                    author,
                    likesCount,
                    retweetsCount,
                    repliesCount,
                    url: url ? `https://twitter.com${url}` : undefined,
                    originalPost: {
                        id: "",
                        content: quoteContent,
                        timestamp: "",
                        author: originalAuthor,
                    },
                    hasQuote,
                    quoteComment,
                });
                return;
            }
            // Normal tweet
            posts.push({
                type: "normal",
                id,
                content: contentElement.textContent || "",
                timestamp,
                author,
                likesCount,
                retweetsCount,
                repliesCount,
                url: url ? `https://twitter.com${url}` : undefined,
            });
            console.log(`Successfully processed tweet ${index + 1}`);
        });
        return posts;
    }
    catch (error) {
        console.error("Error extracting tweets from DOM:", error);
        return [];
    }
}
async function extractTwitterPostsFromAi(html, settings) {
    try {
        console.log("Starting AI-based extraction...");
        const prompt = `You are a Twitter HTML parser. Given the HTML content of a Twitter profile page, extract all the tweets. For each tweet, identify if it's a normal tweet, reply, or repost. Include:
1. Tweet content and metadata (timestamp, likes, retweets, replies)
2. Author information (username, display name)
3. For replies: include the original tweet being replied to
4. For reposts: include the original tweet and whether it has a quote

Return the data as a JSON array of objects with this structure:
{
  "type": "normal" | "reply" | "repost",
  "id": "tweet id",
  "content": "tweet content",
  "timestamp": "ISO timestamp",
  "author": {
    "username": "username without @",
    "displayName": "display name",
    "profileUrl": "https://twitter.com/username"
  },
  "likesCount": number,
  "retweetsCount": number,
  "repliesCount": number,
  "url": "tweet URL",
  // For replies only:
  "replyTo": {
    "content": "original tweet content",
    "author": { same as above }
  },
  // For reposts only:
  "originalPost": {
    "content": "original tweet content",
    "author": { same as above }
  },
  "hasQuote": boolean,
  "quoteComment": string or null
}

HTML Content:
${html}`;
        console.log("Sending request to AI model...");
        const result = await (0,_services_ai__WEBPACK_IMPORTED_MODULE_0__.callAiModel)(prompt, settings);
        console.log("Received AI response, parsing JSON...");
        try {
            const parsedPosts = JSON.parse(result);
            if (Array.isArray(parsedPosts)) {
                console.log(`Successfully parsed ${parsedPosts.length} posts from AI response`);
                return parsedPosts;
            }
            console.error("AI returned invalid format:", result);
            return [];
        }
        catch (error) {
            console.error("Failed to parse AI response:", error);
            return [];
        }
    }
    catch (error) {
        console.error("Error in AI extraction:", error);
        throw new Error(`Failed to extract tweets using AI: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}
async function extractTwitterPosts(html, settings, options = { enableAI: true }) {
    try {
        console.log("Starting tweet extraction process...");
        // First try DOM extraction
        const domPosts = extractTwitterPostsFromDom();
        console.log(`DOM extraction returned ${domPosts.length} posts`);
        if (domPosts.length > 0) {
            console.log("Using DOM extraction results");
            return domPosts;
        }
        // If DOM extraction failed and AI is enabled, try AI extraction
        if (options.enableAI) {
            console.log("DOM extraction failed, falling back to AI extraction...");
            return await extractTwitterPostsFromAi(html, settings);
        }
        console.log("DOM extraction failed and AI fallback is disabled");
        return [];
    }
    catch (error) {
        console.error("Error extracting tweets:", error);
        throw new Error(`Failed to extract tweets: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}


/***/ }),

/***/ "./src/types/index.ts":
/*!****************************!*\
  !*** ./src/types/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_SETTINGS: () => (/* binding */ DEFAULT_SETTINGS)
/* harmony export */ });
const DEFAULT_SETTINGS = {
    openaiUrl: 'https://openrouter.ai/api/v1',
    model: 'google/gemini-2.0-flash-001',
    enableAutoReply: false,
    enableAutoSubmit: false,
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!********************************!*\
  !*** ./src/content/content.ts ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _twitter_timeline__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../twitter/timeline */ "./src/twitter/timeline.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../types */ "./src/types/index.ts");


class ContentAnalyzer {
    constructor() {
        this.settings = _types__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_SETTINGS;
        this.selectedText = '';
        this.contextMenu = null;
        this.loadSettings();
        this.initializeEventListeners();
    }
    async loadSettings() {
        this.settings = await new Promise((resolve) => {
            chrome.storage.sync.get(['settings'], (result) => {
                resolve(result.settings || _types__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_SETTINGS);
            });
        });
    }
    initializeEventListeners() {
        // Listen for text selection
        document.addEventListener('mouseup', (e) => this.handleTextSelection(e));
        // Listen for settings changes
        chrome.storage.onChanged.addListener((changes) => {
            if (changes.settings) {
                this.settings = changes.settings.newValue;
            }
        });
        // Listen for messages from the popup
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log('Content script received message:', request);
            if (request.type === 'ANALYZE_PAGE') {
                console.log('Starting page analysis...');
                this.analyzePageContent();
            }
        });
    }
    async analyzePageContent() {
        console.log('Analyzing page content...');
        console.log('Is Twitter profile?', this.isTwitterProfilePage());
        // Check if it's a Twitter profile page
        if (this.isTwitterProfilePage()) {
            try {
                console.log('Getting Twitter profile HTML...');
                const html = await this.getTwitterProfileHtml();
                if (!html) {
                    throw new Error('Failed to get Twitter profile HTML');
                }
                console.log('Got HTML, sending to background script...');
                // Send HTML to background script for analysis
                chrome.runtime.sendMessage({
                    type: 'ANALYZE_PROFILE',
                    html: html
                });
            }
            catch (error) {
                console.error('Error analyzing Twitter profile:', error);
                chrome.runtime.sendMessage({
                    type: 'PROFILE_ERROR',
                    error: error instanceof Error ? error.message : 'An unknown error occurred'
                });
            }
        }
        else {
            console.log('Not a Twitter profile page, sending unsupported message');
            chrome.runtime.sendMessage({
                type: 'PROFILE_ERROR',
                error: 'Please navigate to a Twitter/X profile page first.'
            });
        }
    }
    isTwitterProfilePage() {
        return (0,_twitter_timeline__WEBPACK_IMPORTED_MODULE_0__.isTwitterProfileUrl)(window.location.href);
    }
    async getTwitterProfileHtml() {
        try {
            // Simple scroll to load more content
            let lastHeight = document.documentElement.scrollHeight;
            await this.smoothScroll(lastHeight);
            await new Promise(resolve => setTimeout(resolve, 2000));
            // Scroll back to top gently
            await this.smoothScroll(0);
            // Get the cleaned HTML content
            const cleanHtml = document.documentElement.outerHTML
                .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove scripts
                .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '') // Remove styles
                .replace(/<svg\b[^<]*(?:(?!<\/svg>)<[^<]*)*<\/svg>/gi, ''); // Remove SVGs
            return cleanHtml;
        }
        catch (error) {
            console.error('Error getting Twitter profile HTML:', error);
            return null;
        }
    }
    async smoothScroll(targetScroll) {
        const duration = 1000; // 1 second
        const start = window.scrollY;
        const distance = targetScroll - start;
        const startTime = performance.now();
        return new Promise(resolve => {
            function step() {
                const currentTime = performance.now();
                const elapsed = currentTime - startTime;
                if (elapsed >= duration) {
                    window.scrollTo(0, targetScroll);
                    resolve();
                    return;
                }
                // Easing function
                const progress = elapsed / duration;
                const easeProgress = 0.5 - Math.cos(progress * Math.PI) / 2;
                const currentPosition = start + (distance * easeProgress);
                window.scrollTo(0, currentPosition);
                requestAnimationFrame(step);
            }
            requestAnimationFrame(step);
        });
    }
    handleTextSelection(e) {
        const selection = window.getSelection();
        if (!selection || selection.isCollapsed) {
            this.hideContextMenu();
            return;
        }
        const text = selection.toString().trim();
        if (text && text !== this.selectedText) {
            this.selectedText = text;
            this.showContextMenu(e);
        }
    }
    showContextMenu(e) {
        if (this.contextMenu) {
            document.body.removeChild(this.contextMenu);
        }
        this.contextMenu = document.createElement('div');
        this.contextMenu.className = 'fixed z-50 bg-white rounded-lg shadow-lg border border-gray-200 p-2';
        this.contextMenu.style.left = `${e.pageX}px`;
        this.contextMenu.style.top = `${e.pageY}px`;
        const addButton = document.createElement('button');
        addButton.className = 'px-3 py-1 text-sm text-white bg-indigo-600 hover:bg-indigo-700 rounded';
        addButton.textContent = 'Add to Character';
        addButton.onclick = () => this.addTraitToCharacter();
        this.contextMenu.appendChild(addButton);
        document.body.appendChild(this.contextMenu);
        // Close menu when clicking outside
        document.addEventListener('mousedown', (e) => {
            if (this.contextMenu && !this.contextMenu.contains(e.target)) {
                this.hideContextMenu();
            }
        }, { once: true });
    }
    hideContextMenu() {
        if (this.contextMenu) {
            document.body.removeChild(this.contextMenu);
            this.contextMenu = null;
        }
        this.selectedText = '';
    }
    async addTraitToCharacter() {
        if (!this.selectedText)
            return;
        // Send selected text to background script for analysis
        chrome.runtime.sendMessage({
            type: 'ANALYZE_PROFILE',
            html: this.selectedText
        });
        this.hideContextMenu();
    }
    // Add styles for the context menu
    injectStyles() {
        const style = document.createElement('style');
        style.textContent = `
      .fixed {
        position: fixed;
      }
      .z-50 {
        z-index: 50;
      }
      .bg-white {
        background-color: white;
      }
      .rounded-lg {
        border-radius: 0.5rem;
      }
      .shadow-lg {
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      }
      .border {
        border-width: 1px;
      }
      .border-gray-200 {
        border-color: #e5e7eb;
      }
      .p-2 {
        padding: 0.5rem;
      }
      .px-3 {
        padding-left: 0.75rem;
        padding-right: 0.75rem;
      }
      .py-1 {
        padding-top: 0.25rem;
        padding-bottom: 0.25rem;
      }
      .text-sm {
        font-size: 0.875rem;
      }
      .text-white {
        color: white;
      }
      .bg-indigo-600 {
        background-color: #4f46e5;
      }
      .hover\\:bg-indigo-700:hover {
        background-color: #4338ca;
      }
      .rounded {
        border-radius: 0.25rem;
      }
    `;
        document.head.appendChild(style);
    }
}
// Initialize content analyzer when the page loads
new ContentAnalyzer().injectStyles();

})();

/******/ })()
;
//# sourceMappingURL=content.js.map