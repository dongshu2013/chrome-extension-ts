/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/services/ai.ts":
/*!****************************!*\
  !*** ./src/services/ai.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   callAiModel: () => (/* binding */ callAiModel),
/* harmony export */   summarizeProfile: () => (/* binding */ summarizeProfile)
/* harmony export */ });
class LightOpenAI {
    constructor(config) {
        this.baseURL = config.baseURL;
        this.apiKey = config.apiKey;
    }
    async createChatCompletion(params) {
        const headers = {
            'Content-Type': 'application/json',
        };
        if (this.apiKey) {
            headers['Authorization'] = `Bearer ${this.apiKey}`;
        }
        const response = await fetch(`${this.baseURL}/chat/completions`, {
            method: 'POST',
            headers,
            body: JSON.stringify(params),
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`API error (${response.status}): ${error}`);
        }
        return response.json();
    }
}
async function callAiModel(prompt, settings) {
    try {
        const openai = new LightOpenAI({
            baseURL: settings.openaiUrl,
            apiKey: settings.apiKey,
        });
        const response = await openai.createChatCompletion({
            model: settings.model,
            messages: [{
                    role: 'user',
                    content: prompt
                }],
            temperature: 0.7,
        });
        return response.choices[0].message.content || '';
    }
    catch (error) {
        console.error('Error calling AI model:', error);
        throw new Error(`Failed to call AI model: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}
async function summarizeProfile(posts, existingContent = '', settings) {
    try {
        const prompt = `You are a Twitter profile analyzer. Given a set of tweets, create a concise profile description that captures the key characteristics, interests, and patterns in the user's tweets. If there's existing profile content, incorporate it and update with new insights.

${existingContent ? `Existing Profile Description:\n${existingContent}\n\n` : ''}

Tweets to analyze:
${posts.join('\n')}

Create a natural-sounding profile description that highlights:
1. Main topics and interests
2. Writing style and tone
3. Professional or personal focus
4. Notable patterns or themes`;
        return await callAiModel(prompt, settings);
    }
    catch (error) {
        console.error('Error summarizing profile:', error);
        throw new Error(`Failed to summarize profile: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}


/***/ }),

/***/ "./src/twitter/common.ts":
/*!*******************************!*\
  !*** ./src/twitter/common.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   convertTwitterPostToMarkdown: () => (/* binding */ convertTwitterPostToMarkdown),
/* harmony export */   extractAuthorInfo: () => (/* binding */ extractAuthorInfo)
/* harmony export */ });
function extractAuthorInfo(element) {
    const authorElement = element.querySelector('[data-testid="User-Name"]');
    const displayName = authorElement?.querySelector('span')?.textContent || '';
    const usernameElement = authorElement?.querySelector('[dir="ltr"]');
    const username = usernameElement?.textContent?.replace('@', '') || '';
    const profileUrl = `https://twitter.com/${username}`;
    return {
        username,
        displayName,
        profileUrl
    };
}
function convertTwitterPostToMarkdown(post) {
    console.log('Converting post(s) to markdown format');
    if (Array.isArray(post)) {
        return post.map(p => convertTwitterPostToMarkdown(p)).join('\n\n---\n\n');
    }
    let markdown = `## Tweet by [${post.author.displayName}](${post.author.profileUrl}) ${post.url ? `[🔗](${post.url})` : ''}\n`;
    markdown += `${post.content}\n\n`;
    // Add metadata if available
    const stats = [];
    if (post.likesCount)
        stats.push(`❤️ ${post.likesCount}`);
    if (post.retweetsCount)
        stats.push(`🔄 ${post.retweetsCount}`);
    if (post.repliesCount)
        stats.push(`💬 ${post.repliesCount}`);
    if (stats.length > 0) {
        markdown += `*${stats.join(' · ')}*\n`;
    }
    if (post.timestamp) {
        const date = new Date(post.timestamp);
        markdown += `*Posted on ${date.toLocaleDateString()}*\n`;
    }
    // Add replies if available
    if (post.replies && post.replies.length > 0) {
        markdown += '\n### Replies\n';
        post.replies.forEach(reply => {
            markdown += `\n**[${reply.author.displayName}](${reply.author.profileUrl})**\n`;
            markdown += `${reply.content}\n`;
            if (reply.timestamp) {
                const replyDate = new Date(reply.timestamp);
                markdown += `*Posted on ${replyDate.toLocaleDateString()}*\n`;
            }
            markdown += '---\n';
        });
    }
    // Add replyTo or originalPost if available
    if (post.type === 'reply') {
        markdown += '\n### Original Tweet\n';
        markdown += `**[${post.replyTo.author.displayName}](${post.replyTo.author.profileUrl})**\n`;
        markdown += `${post.replyTo.content}\n`;
        if (post.replyTo.timestamp) {
            const replyToDate = new Date(post.replyTo.timestamp);
            markdown += `*Posted on ${replyToDate.toLocaleDateString()}*\n`;
        }
    }
    else if (post.type === 'repost') {
        markdown += '\n### Original Tweet\n';
        markdown += `**[${post.originalPost.author.displayName}](${post.originalPost.author.profileUrl})**\n`;
        markdown += `${post.originalPost.content}\n`;
        if (post.originalPost.timestamp) {
            const originalPostDate = new Date(post.originalPost.timestamp);
            markdown += `*Posted on ${originalPostDate.toLocaleDateString()}*\n`;
        }
        if (post.hasQuote) {
            markdown += '\n### Quote Comment\n';
            markdown += `${post.quoteComment}\n`;
        }
    }
    console.log('Markdown conversion complete');
    return markdown;
}


/***/ }),

/***/ "./src/twitter/timeline.ts":
/*!*********************************!*\
  !*** ./src/twitter/timeline.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractTwitterPosts: () => (/* binding */ extractTwitterPosts),
/* harmony export */   extractTwitterPostsFromAi: () => (/* binding */ extractTwitterPostsFromAi),
/* harmony export */   extractTwitterPostsFromDom: () => (/* binding */ extractTwitterPostsFromDom),
/* harmony export */   isTwitterProfileUrl: () => (/* binding */ isTwitterProfileUrl),
/* harmony export */   isTwitterReplyUrl: () => (/* binding */ isTwitterReplyUrl)
/* harmony export */ });
/* harmony import */ var _services_ai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/ai */ "./src/services/ai.ts");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./common */ "./src/twitter/common.ts");


function isTwitterProfileUrl(url) {
    // Match twitter.com/username or x.com/username but not subpages
    // Also allow www subdomain
    return /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/?$/.test(url);
}
function isTwitterReplyUrl(url) {
    if (!url)
        return false;
    console.log("Checking if URL is a Twitter reply URL:", url);
    // Match Twitter's reply URL patterns more comprehensively
    return (
    // Match the /intent/tweet pattern
    /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/[^/]+\/tweet/.test(url) ||
        // Match the specific in_reply_to parameter
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/intent\/tweet\?in_reply_to=/.test(url) ||
        // Match the specific in_reply_to parameter for x.com
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/intent\/post\?in_reply_to=/.test(url) ||
        // Match URLs with status and reply in them
        /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+\/status\/[^/]+\/reply/.test(url));
}
function extractTwitterPostsFromDom() {
    try {
        console.log("Starting DOM extraction...");
        const posts = [];
        // Find all tweet articles
        const tweets = document.querySelectorAll('article[data-testid="tweet"]');
        console.log(`Found ${tweets.length} tweets`);
        tweets.forEach((tweet, index) => {
            console.log(`Processing tweet ${index + 1}...`);
            // Find the tweet text content
            const contentElement = tweet.querySelector('[data-testid="tweetText"]');
            if (!contentElement) {
                console.log("No content element found, skipping tweet");
                return;
            }
            const content = contentElement.textContent || "";
            console.log(`- Content: "${content.slice(0, 50)}..."`);
            // Extract author info
            const author = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(tweet);
            console.log(`- Author: ${author.displayName} (@${author.username})`);
            // Find the tweet time element
            const timeElement = tweet.querySelector("time");
            const timestamp = timeElement?.getAttribute("datetime") || "";
            console.log(`- Timestamp: ${timestamp || "not found"}`);
            // Find tweet stats
            const statsContainer = tweet.querySelector('[role="group"]');
            const stats = statsContainer?.querySelectorAll('[data-testid$="count"]') || [];
            const [repliesCount, retweetsCount, likesCount] = Array.from(stats).map((stat) => parseInt(stat?.textContent || "0", 10));
            console.log(`- Stats: ${repliesCount} replies, ${retweetsCount} retweets, ${likesCount} likes`);
            // Find tweet URL
            const linkElement = tweet.querySelector('a[href*="/status/"]');
            const url = linkElement?.getAttribute("href");
            const id = url?.split("/status/")?.[1] || "";
            console.log(`- Tweet ID: ${id || "not found"}`);
            // Check if it's a reply
            const replyElement = tweet.querySelector('[data-testid="tweet-reply-context"]');
            if (replyElement) {
                const replyToAuthor = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(replyElement);
                const replyToContent = replyElement.querySelector('[data-testid="tweetText"]')
                    ?.textContent || "";
                posts.push({
                    type: "reply",
                    id,
                    content: contentElement.textContent || "",
                    timestamp,
                    author,
                    likesCount,
                    retweetsCount,
                    repliesCount,
                    url: url ? `https://twitter.com${url}` : undefined,
                    replyTo: {
                        id: "",
                        content: replyToContent,
                        timestamp: "",
                        author: replyToAuthor,
                    },
                });
                return;
            }
            // Check if it's a repost
            const repostElement = tweet.querySelector('[data-testid="tweet-repost-context"]');
            if (repostElement) {
                const originalAuthor = (0,_common__WEBPACK_IMPORTED_MODULE_1__.extractAuthorInfo)(repostElement);
                const quoteContent = tweet.querySelector('[data-testid="tweet-quoted"]')?.textContent ||
                    "";
                const hasQuote = Boolean(quoteContent);
                const quoteComment = hasQuote
                    ? contentElement.textContent || ""
                    : undefined;
                posts.push({
                    type: "repost",
                    id,
                    content: contentElement.textContent || "",
                    timestamp,
                    author,
                    likesCount,
                    retweetsCount,
                    repliesCount,
                    url: url ? `https://twitter.com${url}` : undefined,
                    originalPost: {
                        id: "",
                        content: quoteContent,
                        timestamp: "",
                        author: originalAuthor,
                    },
                    hasQuote,
                    quoteComment,
                });
                return;
            }
            // Normal tweet
            posts.push({
                type: "normal",
                id,
                content: contentElement.textContent || "",
                timestamp,
                author,
                likesCount,
                retweetsCount,
                repliesCount,
                url: url ? `https://twitter.com${url}` : undefined,
            });
            console.log(`Successfully processed tweet ${index + 1}`);
        });
        return posts;
    }
    catch (error) {
        console.error("Error extracting tweets from DOM:", error);
        return [];
    }
}
async function extractTwitterPostsFromAi(html, settings) {
    try {
        console.log("Starting AI-based extraction...");
        const prompt = `You are a Twitter HTML parser. Given the HTML content of a Twitter profile page, extract all the tweets. For each tweet, identify if it's a normal tweet, reply, or repost. Include:
1. Tweet content and metadata (timestamp, likes, retweets, replies)
2. Author information (username, display name)
3. For replies: include the original tweet being replied to
4. For reposts: include the original tweet and whether it has a quote

Return the data as a JSON array of objects with this structure:
{
  "type": "normal" | "reply" | "repost",
  "id": "tweet id",
  "content": "tweet content",
  "timestamp": "ISO timestamp",
  "author": {
    "username": "username without @",
    "displayName": "display name",
    "profileUrl": "https://twitter.com/username"
  },
  "likesCount": number,
  "retweetsCount": number,
  "repliesCount": number,
  "url": "tweet URL",
  // For replies only:
  "replyTo": {
    "content": "original tweet content",
    "author": { same as above }
  },
  // For reposts only:
  "originalPost": {
    "content": "original tweet content",
    "author": { same as above }
  },
  "hasQuote": boolean,
  "quoteComment": string or null
}

HTML Content:
${html}`;
        console.log("Sending request to AI model...");
        const result = await (0,_services_ai__WEBPACK_IMPORTED_MODULE_0__.callAiModel)(prompt, settings);
        console.log("Received AI response, parsing JSON...");
        try {
            const parsedPosts = JSON.parse(result);
            if (Array.isArray(parsedPosts)) {
                console.log(`Successfully parsed ${parsedPosts.length} posts from AI response`);
                return parsedPosts;
            }
            console.error("AI returned invalid format:", result);
            return [];
        }
        catch (error) {
            console.error("Failed to parse AI response:", error);
            return [];
        }
    }
    catch (error) {
        console.error("Error in AI extraction:", error);
        throw new Error(`Failed to extract tweets using AI: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}
async function extractTwitterPosts(html, settings, options = { enableAI: true }) {
    try {
        console.log("Starting tweet extraction process...");
        // First try DOM extraction
        const domPosts = extractTwitterPostsFromDom();
        console.log(`DOM extraction returned ${domPosts.length} posts`);
        if (domPosts.length > 0) {
            console.log("Using DOM extraction results");
            return domPosts;
        }
        // If DOM extraction failed and AI is enabled, try AI extraction
        if (options.enableAI) {
            console.log("DOM extraction failed, falling back to AI extraction...");
            return await extractTwitterPostsFromAi(html, settings);
        }
        console.log("DOM extraction failed and AI fallback is disabled");
        return [];
    }
    catch (error) {
        console.error("Error extracting tweets:", error);
        throw new Error(`Failed to extract tweets: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
}


/***/ }),

/***/ "./src/types/index.ts":
/*!****************************!*\
  !*** ./src/types/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_SETTINGS: () => (/* binding */ DEFAULT_SETTINGS)
/* harmony export */ });
const DEFAULT_SETTINGS = {
    openaiUrl: 'https://openrouter.ai/api/v1',
    model: 'google/gemini-2.0-flash-001',
    enableAutoReply: false,
    enableAutoSubmit: false,
};


/***/ }),

/***/ "./src/utils/common.ts":
/*!*****************************!*\
  !*** ./src/utils/common.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sleep: () => (/* binding */ sleep)
/* harmony export */ });
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}


/***/ }),

/***/ "./src/utils/url.ts":
/*!**************************!*\
  !*** ./src/utils/url.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isBuzzWebsiteUrl: () => (/* binding */ isBuzzWebsiteUrl),
/* harmony export */   isTwitterProfileUrl: () => (/* binding */ isTwitterProfileUrl)
/* harmony export */ });
function isTwitterProfileUrl(url) {
    // Match twitter.com/username or x.com/username but not subpages
    // Also allow www subdomain
    return /^https?:\/\/((?:www\.)?twitter\.com|(?:www\.)?x\.com)\/[^/]+$/.test(url);
}
function isBuzzWebsiteUrl(url) {
    console.log("check isBuzzWebsiteUrl", url);
    return (url.startsWith("http://localhost:3000") ||
        url.startsWith("https://buzz.ai") ||
        url.startsWith("https://staging.buzzz.fun"));
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!**************************************!*\
  !*** ./src/background/background.ts ***!
  \**************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _services_ai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/ai */ "./src/services/ai.ts");
/* harmony import */ var _twitter_timeline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../twitter/timeline */ "./src/twitter/timeline.ts");
/* harmony import */ var _twitter_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../twitter/common */ "./src/twitter/common.ts");
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../types */ "./src/types/index.ts");
/* harmony import */ var _utils_url__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/url */ "./src/utils/url.ts");
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/common */ "./src/utils/common.ts");






// Initialize extension settings if not already set
chrome.runtime.onInstalled.addListener(async () => {
    console.log("Extension installed/updated");
    const settings = await new Promise((resolve) => {
        chrome.storage.sync.get(["settings"], (result) => {
            resolve(result.settings);
        });
    });
    if (!settings) {
        console.log("Initializing default settings");
        await new Promise((resolve) => {
            chrome.storage.sync.set({ settings: _types__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_SETTINGS }, resolve);
        });
    }
});
// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Background received message:", message);
    if (message.type === "ANALYZE_PROFILE") {
        handleProfileAnalysis(message.html);
        return true; // Will respond asynchronously
    }
    if (message.type === "PROFILE_TRAIT") {
        console.log("Handling profile trait update");
        // Save the profile data
        chrome.storage.sync.get(["profile"], (result) => {
            console.log("Retrieved profile:", result.profile);
            const profile = message.data.text;
            chrome.storage.sync.set({ profile }, () => {
                console.log("Profile saved, forwarding to popup");
                // Forward the text data to the popup
                chrome.runtime.sendMessage({
                    type: "PAGE_ANALYSIS",
                    data: {
                        text: profile,
                    },
                });
            });
        });
    }
    if (message.type === "GET_PROFILE_CONTENT") {
        console.log("Getting profile content");
        // Retrieve existing profile content
        chrome.storage.sync.get(["profile"], (result) => {
            console.log("Retrieved profile:", result);
            sendResponse({ content: result.profile || "" });
        });
        return true; // Required for async response
    }
    if (message.type === "AUTO_REPLY_BUZZ") {
        autoReplyBuzz();
        return true;
    }
    if (message.type === "TEST_TWITTER") {
        testTwitter();
        return true;
    }
    if (message.type === "TEST_BUZZ_INPUT") {
        handleTestBuzzInput();
        return true;
    }
});
// Add tab monitoring
chrome.tabs.onCreated.addListener(async (tab) => {
    console.log("New tab created:", tab);
    if (!tab?.id) {
        return;
    }
    // const openerTabId = tab.openerTabId;
    // if (openerTabId) {
    //   console.log("Opener tab id:", openerTabId);
    //   chrome.tabs.get(openerTabId, (openerTab) => {
    //     console.log("Opener tab:", openerTab);
    //   });
    // }
    await (0,_utils_common__WEBPACK_IMPORTED_MODULE_5__.sleep)(3000);
    const tabDetail = await chrome.tabs.get(tab.id);
    console.log("Tab url:", tabDetail.url);
    console.log("is twitter reply url:", (0,_twitter_timeline__WEBPACK_IMPORTED_MODULE_1__.isTwitterReplyUrl)(tabDetail.url || ""));
    const isTwitterReply = (0,_twitter_timeline__WEBPACK_IMPORTED_MODULE_1__.isTwitterReplyUrl)(tabDetail.url || "");
    // Check if it's a URL of twitter reply
    if (isTwitterReply) {
        console.log("Twitter reply tab detected");
        // You can send a message to inform other parts of your extension
        handleNewTwitterReplyTab(tab.id);
    }
});
async function handleProfileAnalysis(html) {
    try {
        // Get settings
        const settings = await new Promise((resolve) => {
            chrome.storage.sync.get(["settings"], (result) => {
                resolve(result.settings || _types__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_SETTINGS);
            });
        });
        // Extract posts
        const posts = await (0,_twitter_timeline__WEBPACK_IMPORTED_MODULE_1__.extractTwitterPosts)(html, settings);
        if (posts.length === 0) {
            throw new Error("No posts found on this profile");
        }
        // Get existing profile content
        const existingContent = await getExistingProfile("");
        // Generate summary
        const postsMarkdown = (0,_twitter_common__WEBPACK_IMPORTED_MODULE_2__.convertTwitterPostToMarkdown)(posts).split("\n");
        const updatedProfile = await (0,_services_ai__WEBPACK_IMPORTED_MODULE_0__.summarizeProfile)(postsMarkdown, existingContent, settings);
        // Save and broadcast the result
        chrome.storage.sync.set({ profile: updatedProfile }, () => {
            chrome.runtime.sendMessage({
                type: "PAGE_ANALYSIS",
                data: {
                    text: updatedProfile,
                },
            });
        });
    }
    catch (error) {
        console.error("Error in profile analysis:", error);
        chrome.runtime.sendMessage({
            type: "PROFILE_ERROR",
            error: error instanceof Error ? error.message : "An unknown error occurred",
        });
    }
}
// Helper function to get existing profile content
async function getExistingProfile(url) {
    console.log("Getting existing profile content", url);
    return await new Promise((resolve) => {
        chrome.storage.sync.get(["profile"], (result) => {
            resolve(result.profile || "");
        });
    });
}
async function autoReplyBuzz() {
    try {
        console.log("Start auto-reply buzz...");
        const tabs = await chrome.tabs.query({});
        const buzzTab = tabs.find((t) => t?.url && (0,_utils_url__WEBPACK_IMPORTED_MODULE_4__.isBuzzWebsiteUrl)(t.url));
        if (!buzzTab?.id) {
            console.error("No Buzz tab found");
            return;
        }
        // Execute in the context of the web page
        const replyBuzzButtons = await chrome.scripting.executeScript({
            target: { tabId: buzzTab.id },
            func: () => {
                const replyBuzzButtons = document.querySelectorAll('[id^="replyBuzz-"]');
                const replyBuzzButton = replyBuzzButtons[0];
                if (replyBuzzButton) {
                    replyBuzzButton.click();
                }
                else {
                    console.log("No reply buzz button found");
                }
                return Array.from(replyBuzzButtons).map((el) => el.id);
            },
        });
    }
    catch (error) {
        console.error("Error starting auto reply buzz:", error);
    }
}
async function testTwitter() {
    console.log("Start test twitter");
    const tabs = await chrome.tabs.query({ active: true });
    handleNewTwitterReplyTab(tabs[0]?.id);
}
async function handleNewTwitterReplyTab(tabId) {
    if (!tabId) {
        console.error("handleNewTwitterReplyTab: No tab id found");
        return;
    }
    try {
        console.log("New twitter reply tab detected:", tabId);
        // Click reply in twitter
        const result = await chrome.scripting
            .executeScript({
            target: { tabId },
            func: async () => {
                console.log("Start script in twitter");
                const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
                let retryCount = 0;
                let replyButton = null;
                while (retryCount < 10) {
                    retryCount++;
                    await sleep(1000);
                    const toolbar = document.querySelector('div[data-testid="toolBar"]');
                    if (!toolbar) {
                        console.log("Toolbar not found");
                        return null;
                    }
                    // Now find the reply button within the toolbar
                    replyButton = toolbar.querySelector('button[data-testid="tweetButton"]');
                    if (replyButton) {
                        break;
                    }
                }
                if (replyButton) {
                    console.log("twitter replyButton found:", replyButton);
                    try {
                        console.log("twitter replyButton click");
                        replyButton.click();
                        retryCount = 0;
                        let newPostHref = "";
                        while (retryCount < 10) {
                            retryCount++;
                            await sleep(1000);
                            const alert = document.querySelector('[role="alert"]');
                            if (alert) {
                                console.log("twitter alert found:", alert);
                                const viewLink = alert.querySelector('a[role="link"] span');
                                // If the link is found, get its href
                                if (viewLink &&
                                    (viewLink.textContent === "查看" ||
                                        viewLink.textContent === "View")) {
                                    const linkElement = viewLink.closest("a");
                                    const hrefValue = linkElement
                                        ? linkElement.getAttribute("href")
                                        : null;
                                    console.log("Found href:", hrefValue);
                                    newPostHref = hrefValue || "";
                                    break;
                                }
                            }
                        }
                        return newPostHref;
                    }
                    catch (err) {
                        console.error("twitter replyButton click error:", err);
                    }
                }
                else {
                    console.log("No reply button found");
                }
            },
        })
            .catch((err) => {
            console.error("twitter replyButton click error:", err);
        });
        // Close the tab after processing
        await chrome.tabs.remove(tabId);
        let newPostFullUrl = undefined;
        if (result && result[0] && result[0].result) {
            const newPostHref = result[0].result;
            if (newPostHref) {
                newPostFullUrl = `https://twitter.com${newPostHref}`;
            }
        }
        await handleNewTwitterReplyFinished(newPostFullUrl);
    }
    catch (err) {
        console.error("Error handling new twitter reply tab:", err);
    }
}
async function handleNewTwitterReplyFinished(replyUrl) {
    console.log("New twitter reply finished:", replyUrl);
    try {
        const tabs = await chrome.tabs.query({});
        const buzzTab = tabs.find((t) => t?.url && (0,_utils_url__WEBPACK_IMPORTED_MODULE_4__.isBuzzWebsiteUrl)(t.url));
        if (!buzzTab?.id) {
            console.error("No Buzz tab found");
            return;
        }
        // Execute in the context of the web page
        await chrome.scripting.executeScript({
            target: { tabId: buzzTab.id },
            func: (url) => {
                try {
                    if (!url) {
                        return;
                    }
                    // Find input of id replyLink
                    const replyLinkInput = document.querySelector('[id="replyLink"]');
                    if (replyLinkInput) {
                        replyLinkInput.value = url;
                    }
                    const replyBuzzButtons = document.querySelectorAll('[id^="comfirmReply"]');
                    const replyBuzzButton = replyBuzzButtons[0];
                    if (replyBuzzButton) {
                        replyBuzzButton.click();
                    }
                    else {
                        console.log("No confirm reply button found");
                    }
                    return Array.from(replyBuzzButtons).map((el) => el.id);
                }
                catch (err) {
                    console.error("Error handling new twitter reply finished:", err);
                }
                finally {
                }
            },
            args: [replyUrl],
        });
    }
    catch (error) {
        console.error("Error starting auto reply buzz:", error);
    }
}
async function handleTestBuzzInput() {
    try {
        const tabs = await chrome.tabs.query({});
        const buzzTab = tabs.find((t) => t?.url && (0,_utils_url__WEBPACK_IMPORTED_MODULE_4__.isBuzzWebsiteUrl)(t.url));
        if (!buzzTab?.id) {
            console.error("No Buzz tab found");
            return;
        }
        // Execute in the context of the web page
        await chrome.scripting.executeScript({
            target: { tabId: buzzTab.id },
            func: () => {
                try {
                    // Find input of id replyLink
                    const replyLinkInput = document.querySelector('[id="replyLink"]');
                    console.log("replyLinkInput:", replyLinkInput);
                    if (replyLinkInput) {
                        replyLinkInput.value = "https://www.google.com";
                    }
                    const replyBuzzButtons = document.querySelectorAll('[id^="comfirmReply"]');
                    const replyBuzzButton = replyBuzzButtons[0];
                    if (replyBuzzButton) {
                        replyBuzzButton.click();
                    }
                    else {
                        console.log("No confirm reply button found");
                    }
                    return Array.from(replyBuzzButtons).map((el) => el.id);
                }
                catch (err) {
                    console.error("Error handling test buzz input:", err);
                }
                finally {
                }
            },
        });
    }
    catch (error) {
        console.error("Error starting auto reply buzz:", error);
    }
}

})();

/******/ })()
;
//# sourceMappingURL=background.js.map